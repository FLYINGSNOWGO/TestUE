//
// Created by Administrator on 2020/5/27.
//
#pragma once
#include "CoreMinimal.h"
#include "ThreadingBase.h"
#include "Networking.h"
#include "DsSkillService.h"
#include "HAL/Runnable.h"

#include <string>
#include <iostream>
#include <memory>
//#include <grpcpp/grpcpp.h>
//#include <grpcpp/health_check_service_interface.h>
// #include <grpcpp/ext/proto_server_reflection_plugin.h>


//using grpc::Server;
//using grpc::ServerBuilder;
//using grpc::ServerContext;
//using grpc::Status;

class SQLITE_API FGrpcServerThread : public FRunnable 
{
public:
	FGrpcServerThread() {}
	virtual bool Init();
	virtual uint32 Run() override;
	virtual void Exit() override;
private:
	void StartListen();
};
