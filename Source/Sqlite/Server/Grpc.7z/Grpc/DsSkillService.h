#pragma once
//#include "Server/HARIX/proto/robot-mind/robotskill.pb.h"
//#include "Server/HARIX/proto/robot-mind/robotskill.grpc.pb.h"
//
//
//class ASqliteCharacter;
//
//using robotmind::RobotSkillService;
//
//using grpc::Channel;
//using grpc::ServerContext;
//using grpc::Status;
//using grpc::StatusCode;
//
//using robotmind::EnableSkillRequest;
//using robotmind::EnableSkillResponse;
//using robotmind::ActionRequest;
//using robotmind::ActionResponse;


//class FDsSkillService final :
//	public RobotSkillService::Service
//{
//public:
//	FDsSkillService() {};
//	void Init();
//	// EnableSkill、HandleAction 来源于robotskill.proto里定义的 [11/16/2021 CarlZhou]
//	Status EnableSkill(ServerContext * context, const EnableSkillRequest * request, EnableSkillResponse * response) override;
//	Status HandleAction(ServerContext* context, const ActionRequest* request, ActionResponse* response) override;
//	void DealHandleAction(ASqliteCharacter* character, FString id, FString param);
//	void DetectFace(ASqliteCharacter* character, const FString& face_param);
//private:
//};

