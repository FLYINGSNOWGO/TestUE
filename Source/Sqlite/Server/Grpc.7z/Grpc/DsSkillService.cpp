#include "DsSkillService.h"
#include "Engine/World.h"
#include "Server/Runtime/ServerGameMode.h"
#include "Common/Runtime/SqliteCharacter.h"


//void FDsSkillService::Init()
//{
//	UE_LOG(LogTemp, Warning, TEXT("[DsSkillService] Init invoke"));
//	//CsClient::GetInstance(); 
//}
//
//Status FDsSkillService::EnableSkill(ServerContext* context, 
//	const EnableSkillRequest* request, EnableSkillResponse* response) {
//	UE_LOG(LogTemp, Warning, TEXT("##-- [DsSkillService] Received EnableSkill invoke"));
//	FString fDebug = request->DebugString().c_str();
//	UE_LOG(LogTemp, Warning, TEXT("##-- [DsSkillService] EnableSkill Request Debug string: %s"), *fDebug);
//
//	UE_LOG(LogTemp, Warning, TEXT("enter login"));
//
//	AServerGameMode* gamemode = GWorld->GetAuthGameMode<AServerGameMode>();
//	if (gamemode == nullptr)
//	{
//		UE_LOG(LogTemp, Warning, TEXT("get ARobotEngineServerGameMode failed"));
//	}
//	else {
//		UE_LOG(LogTemp, Log, TEXT("set gamemode robot type and id"));
//		/*gamemode->m_actorType = FString(request->common_req_info().robot_type().c_str());
//		gamemode->m_actorRobotid = FString(request->common_req_info().robot_id().c_str());
//		gamemode->m_userid = FString(request->common_req_info().user_id().c_str());
//		gamemode->m_input_tenentid = FString(request->common_req_info().tenant_id().c_str());
//		gamemode->m_serviceCode = FString(request->common_req_info().service_code().c_str());*/
//	}
//
//	UE_LOG(LogTemp, Warning, TEXT("##--DsSkillService::EnableSkill After invoke EnableSkill"));
//	return Status::OK;
//}
//
//Status FDsSkillService::HandleAction(ServerContext * context, const ActionRequest * request, ActionResponse * response)
//{
//	return Status::OK;
//}
//
//void FDsSkillService::DealHandleAction(ASqliteCharacter* character,
//	FString id, FString param)
//{
//}
//
//void FDsSkillService::DetectFace(ASqliteCharacter* character, const FString& face_param)
//{
//}
