#include "GrpcServerThread.h"
bool FGrpcServerThread::Init()
{
	UE_LOG(LogTemp, Warning, TEXT("--------------------thread init--------------------"));
	return true;
}

uint32 FGrpcServerThread::Run()
{
	UE_LOG(LogTemp, Warning, TEXT("--------------------thread run--------------------"));
	this->StartListen();
	return uint32();
}

void FGrpcServerThread::Exit()
{
	UE_LOG(LogTemp, Warning, TEXT("--------------------thread exit--------------------"));
}

void FGrpcServerThread::StartListen()
{
	UE_LOG(LogTemp, Warning, TEXT("--------------------GrpcServer RunServer--------------------"));

	//std::string server_address("0.0.0.0:50051");
	FString grpcHost = TEXT("0.0.0.0:33789");
	std::string server_address(TCHAR_TO_UTF8(*grpcHost));

	grpc::EnableDefaultHealthCheckService(true);
	//grpc::reflection::InitProtoReflectionServerBuilderPlugin();
	UE_LOG(LogTemp, Warning, TEXT("-------------------1--------------------"));
	ServerBuilder builder;
	// Listen on the given address without any authentication mechanism.
	builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
	// Register "service" as the instance through which we'll communicate with
	// clients. In this case it corresponds to an *synchronous* service.
	/*UE_LOG(LogTemp, Warning, TEXT("-------------------reg ds skill service--------------------"));
	FDsSkillService dsSkillService;
	dsSkillService.Init();
	builder.RegisterService(&dsSkillService);*/

	/*UE_LOG(LogTemp, Warning, TEXT("-------------------reg ds switch service--------------------"));
	DsSwitchService dsSwitchService;
	dsSwitchService.Init();
	builder.RegisterService(&dsSwitchService);
	UE_LOG(LogTemp, Warning, TEXT("-------------------3--------------------"));*/

	/*UE_LOG(LogTemp, Warning, TEXT("-------------------reg ds UE4GrpcMsg--------------------"));
	UE4GrpcMsg ue4GrpcMsg;
	ue4GrpcMsg.Init();
	builder.RegisterService(&ue4GrpcMsg);*/

	// Finally assemble the server.
	std::unique_ptr<Server> server(builder.BuildAndStart());

	UE_LOG(LogTemp, Warning, TEXT("==========Server listening on %s================"),*grpcHost);
	// Wait for the server to shutdown. Note that some other thread must be
	// responsible for shutting down the server for this call to ever return.
	server->Wait();
}