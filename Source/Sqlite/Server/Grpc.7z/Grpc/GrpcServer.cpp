#include "GrpcServer.h"
#include "GrpcServerThread.h"
#include "Log.h"

// init
void FGrpcServer::Init()
{
	FScopeLog InitGameLog(*FString::Printf(TEXT("FGrpcServer::Init,Address:%p"), this));
}

// run server
void FGrpcServer::RunServer()
{
	FScopeLog InitGameLog(*FString::Printf(TEXT("FGrpcServer::RunServer,Address:%p"), this));
	UE_LOG(LogTemp, Warning, TEXT("-------------------Create GrpcServer Thread--------------------"));
	// m_GrpcServerThread = FRunnableThread::Create(new GrpcServerThread(), TEXT("RecvThread"));
	FGrpcServerThread* thread = new FGrpcServerThread();
	thread->Init();
	FRunnableThread::Create(thread, TEXT("GrpcServerThread"));
}