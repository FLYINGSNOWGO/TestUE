#pragma once

class SQLITE_API FGrpcServer
{
public:
	FGrpcServer() {};
	void Init();
	void RunServer();
private:
	// FRunnableThread m_GrpcServerThread;
};